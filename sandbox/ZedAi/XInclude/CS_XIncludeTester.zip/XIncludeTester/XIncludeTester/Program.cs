using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
// The Mvp.Xml library has the XInclude support:
// http://www.codeplex.com/MVPXML/Wiki/View.aspx?title=XInclude.NET&referringTitle=Home
using Mvp.Xml.XInclude;

namespace org.rfbd.jpritchett
{
    class Program
    {
        /// <summary>
        /// Command-line tool to apply an XSLT transform to a document that uses XInclude
        /// jpritchett@rfbd.org
        /// 12 Jan 2009
        /// </summary>
        /// <param name="args">infile xslt outfile</param>
        static void Main(string[] args)
        {
            System.Console.WriteLine("XIncludeTester, 12 Jan 2009");
            if (args.Length != 3)
            {
                System.Console.WriteLine("Usage:  XIncludeTester infile xslt outfile");
            }
            else
            {
                XIncludeTester xit = new XIncludeTester();
                xit.doTransform(args[0], args[1], args[2]);

                System.Console.WriteLine("Done.");
            }
        }
    }

    /// <summary>
    /// Class that actually does the work of applying the XSLT
    /// </summary>
    class XIncludeTester
    {
        /// <summary>
        /// Do an XSLT transform on a file that may use XInclude
        /// </summary>
        /// <param name="infileName">Input XML document full path/name</param>
        /// <param name="xsltName">XSLT document full path/name</param>
        /// <param name="outfileName">Output XML document full path/name</param>
        public void doTransform(String infileName, String xsltName, String outfileName)
        {
            // Set up the transform
            XslCompiledTransform xslt = new XslCompiledTransform();
            xslt.Load(xsltName);

            // Create the XmlReader as an XIncludingReader, which will handle all includes
            XmlReader reader = new XIncludingReader(infileName);
            XPathDocument xdoc = new XPathDocument(reader);

            // Do the transform!
            xslt.Transform(xdoc, null, new StreamWriter(outfileName));
        }
    }
}
